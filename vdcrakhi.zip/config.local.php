<?php

return [
    'smtp_host'       => 'smtp.gmail.com',
    'smtp_port'       => 465,
    'smtp_encryption' => 'ssl',
    'smtp_username'   => 'rakhis@elitemart.co.in',
    'smtp_password'   => 'jvaf detq aegt tnei',
    'mail_from'       => 'rakhis@elitemart.co.in',
    'mail_from_name'  => 'Vdesiconnect',
    'admin_email'     => 'rakhis@elitemart.co.in',
];
